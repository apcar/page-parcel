# PageParcel Sample Page

> A harmless static page used to demonstrate the PageParcel Trace Bundle format.

## Pack the page. Keep the record.

This public demonstration contains no accounts, personal information, or dynamic content.

### Visual truth

Lossless PNG captures preserve what the browser rendered.

### Useful structure

Markdown keeps headings, links, lists, and readable page text.

### Source context

Metadata records the page title, URL, timestamp, and capture geometry.

### Integrity register

SHA-256 hashes make later changes to bundled artifacts detectable.
